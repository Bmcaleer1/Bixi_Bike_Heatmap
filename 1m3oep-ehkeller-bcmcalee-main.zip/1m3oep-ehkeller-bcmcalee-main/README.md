# 1m3oep-ehkeller-bcmcalee
Evan Keller and Brendan McAleer

- Any added installations necessary to run the program
- A summary of your program
  Our program creates a heat map of Bixi Bike locations in Montreal based on the number of bikes in the station.
- Which language your program starts in, and which other language(s) it uses
- How you use each language in the program and why the language is a good choice for that use
- How the languages are connected (i.e. which one calls which, and where in your code)
- Any known bugs at time of submission
- Future work (how you could expand the program with more time)
- Citations for any code not written by you or the instructor
- The grade you think you have earned, based on the grading rubric below, with justification

bricks all day