//
// Created by brend on 10/24/2024.
//
#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}